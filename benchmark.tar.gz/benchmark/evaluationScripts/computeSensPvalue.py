#!/usr/bin/python

import sys, os, pdb, random

totalTrials = 100000

def sensitivity(lst1,lst2):

        o = 0.0

        length = 0
        for l in range(len(lst1)):
            o += overlap(lst1[l], lst2[l])
            length += lst1[l][1] - lst1[l][0]
            
        return o/ length

def sampleMods(size, orig):
    
    pmods  =[]
    
    for seq in orig:
        start = random.randint(0,seq)
        pmods.append((start, start + size))
        
    return pmods
                                                            

def getPredictions(file, size):

    predictions = []

    f = open(file,'r').readlines()

    for line in f:
	    if line.find("module") >= 0:
		    tokens = line.strip().split()
		    start = eval(tokens[2])
		    predictions.append((start, start + size))
		    
    return predictions

def getModules(file):

    modules = []

    f = open(file,'r').readlines()

    for line in f:
	    if line[0] != '>':
		    tokens = line.strip().split()
		    modules.append((eval(tokens[0]),eval(tokens[1])))
		    

    return modules

def overlap((s1,e1),(s2,e2)):

	o = min(e1,e2) - max(s1,s2)
	if o < 0:
		return 0

	return o + 1
	

def getStats(predictions, modules):

    union = 0.0
    inter = 0.0
    totalModule = 0.0
    totalPrediction = 0.0

    for i in range(len(predictions)):
	    interI= overlap(predictions[i],modules[i])

	    inter += interI
	    union = predictions[i][1] - predictions[i][0] + 1 + modules[i][1] - modules[i][0] + 1 - inter
	    totalPrediction += predictions[i][1] - predictions[i][0] + 1
	    totalModule += modules[i][1] - modules[i][0] + 1

    return inter,union,totalModule,totalPrediction

def runP(fasta, mods, predictionLength, sens):

    seq = []
    global totalTrials
    
    f = open(fasta,'r').readlines()
    for line in f:
        if line[0] != '>':
            seq.append(len(line.strip()))
            
    better = 0.0

    for i in range(totalTrials):
        
        pmods = sampleMods(predictionLength, seq)
        psens = sensitivity(mods, pmods)
        
        if psens >= sens:
            better +=1
            
    return better/totalTrials
        

def getAvgModule(fasta):

	f = open(fasta,'r').readlines()

	mod = 0.0
	
	for line in f:
		if line[0] != '>':
			tokens = map(eval,line.strip().split())
			mod += tokens[1] - tokens[0]

	return  int(mod/(len(f)/2))
		
        
def getSetStatPvalue(dir, prediction, size):

	modules = getModules(dir + "/positions.txt")
	predictions = getPredictions(prediction, size)

	inter,union,totalMod,totalPred = getStats(predictions,modules)

	return inter/totalMod, runP(dir + "/modules_randomflank.fa", modules, size,inter/totalMod)

if __name__ == "__main__":

	if len(sys.argv) <= 3:
		print "[position file] [prediction file] [size]"
		print "example command: ./computeSensPvalue.py ../dataSets-fasta/mapping1.adult_mesoderm/ ../sampleOutput-mapping1.adult_mesoderm.txt 561"
		sys.exit(0)
	elif len(sys.argv) == 4:
		print "sensitivity, p-value"
		print getSetStatPvalue(sys.argv[1],sys.argv[2],eval(sys.argv[3]))
	else:
		print "sensitivity, p-value"
		
		for dir in os.listdir(sys.argv[1]):
			print dir,": ", getSetStatPvalue(sys.argv[1] + "/" + dir,sys.argv[2] + "/" + dir , getAvgModule(sys.argv[1] + "/" + dir + "/positions.txt"))
			


